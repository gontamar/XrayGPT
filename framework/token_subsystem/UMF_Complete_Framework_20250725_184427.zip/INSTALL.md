# Installation and Setup Guide

## System Requirements

### Minimum Requirements
- Python 3.8+
- 8GB RAM
- 4GB GPU memory (for basic inference)

### Recommended Requirements
- Python 3.9+
- 32GB RAM
- 16GB+ GPU memory (for training)
- CUDA 11.8+ or ROCm 5.0+

## Installation Steps

### 1. Environment Setup
```bash
# Create conda environment (recommended)
conda create -n umf python=3.9
conda activate umf

# Or use venv
python -m venv umf_env
source umf_env/bin/activate  # Linux/Mac
# umf_env\Scripts\activate  # Windows
```

### 2. Install Dependencies
```bash
# Install PyTorch (adjust for your CUDA version)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# Install framework dependencies
pip install -r requirements.txt
```

### 3. Install Framework
```bash
# Development installation
pip install -e .

# Or standard installation
python setup.py install
```

### 4. Verify Installation
```bash
python -c "import umf_core_architecture; print('✅ UMF installed successfully!')"
python umf_examples.py
```

## Configuration

### GPU Setup
```bash
# Check GPU availability
python -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}')"
```

### Memory Optimization
For limited memory systems, edit `umf_training_configs.yaml`:
```yaml
training:
  batch_size: 2  # Reduce batch size
  gradient_checkpointing: true
  mixed_precision: true
```

## Troubleshooting

### Common Issues

1. **CUDA Out of Memory**
   - Reduce batch size
   - Enable gradient checkpointing
   - Use mixed precision training

2. **Import Errors**
   - Verify all dependencies are installed
   - Check Python version compatibility

3. **Slow Training**
   - Enable mixed precision
   - Use multiple GPUs if available
   - Optimize data loading

### Getting Help
- Check the examples in `umf_examples.py`
- Review configuration in `umf_training_configs.yaml`
- Refer to the design document `multimodal_framework_design.md`

# UMF Tutorials and Examples

## Quick Start Examples

### 1. Medical Image Analysis
```python
from umf_domain_implementations import MedicalDomain
from umf_core_architecture import UniversalMultimodalFramework

# Initialize medical domain
medical = MedicalDomain()
framework = UniversalMultimodalFramework()

# Analyze chest X-ray
result = medical.analyze_medical_image(
    image_path="chest_xray.jpg",
    query="What abnormalities do you see?",
    modality="xray"
)
print(result.diagnosis)
```

### 2. Autonomous Driving Scene Understanding
```python
from umf_domain_implementations import AutonomousDrivingDomain

# Initialize autonomous driving
autonomous = AutonomousDrivingDomain()

# Process driving scene
scene_analysis = autonomous.analyze_driving_scene(
    camera_data=camera_frames,
    lidar_data=lidar_points,
    query="Identify potential hazards"
)
print(scene_analysis.safety_assessment)
```

### 3. Educational Tutoring
```python
from umf_domain_implementations import EducationDomain

# Initialize education domain
education = EducationDomain()

# Create tutoring session
tutor_response = education.create_tutoring_session(
    subject="mathematics",
    student_level="high_school",
    problem_image="math_problem.png",
    student_query="How do I solve this equation?"
)
print(tutor_response.explanation)
```

## Advanced Usage

### Custom Domain Implementation
```python
from umf_core_architecture import BaseDomain

class CustomDomain(BaseDomain):
    def __init__(self):
        super().__init__()
        self.domain_name = "custom"
        self.specialized_vocab = ["custom_token1", "custom_token2"]
    
    def process_domain_input(self, inputs):
        # Custom processing logic
        return self.apply_domain_adaptation(inputs)
```

### Multi-Modal Training
```python
from umf_enhanced_framework import MultiStageTrainer

# Configure training
trainer = MultiStageTrainer(
    model=your_model,
    config=training_config
)

# Run multi-stage training
trainer.train_stage1()  # Encoder pretraining
trainer.train_stage2()  # Cross-modal alignment
trainer.train_stage3()  # Domain fine-tuning
trainer.train_stage4()  # Instruction following
```

## Best Practices

### 1. Memory Management
- Use gradient checkpointing for large models
- Implement dynamic batching
- Clear cache regularly during training

### 2. Domain Adaptation
- Start with general pretraining
- Fine-tune on domain-specific data
- Use domain-specific evaluation metrics

### 3. Performance Optimization
- Profile your code to identify bottlenecks
- Use mixed precision training
- Optimize data loading pipelines

## Common Patterns

### Error Handling
```python
try:
    result = framework.process_input(data)
except UMFException as e:
    print(f"Framework error: {e}")
    # Handle gracefully
```

### Configuration Management
```python
from umf_core_architecture import ConfigManager

config = ConfigManager.load_config("custom_config.yaml")
framework = UniversalMultimodalFramework(config=config)
```

### Batch Processing
```python
# Process multiple inputs efficiently
results = framework.batch_process(
    inputs=input_batch,
    batch_size=16,
    num_workers=4
)
```

# UMF API Reference

## Core Classes

### UniversalMultimodalFramework
Main framework class for multimodal processing.

```python
class UniversalMultimodalFramework:
    def __init__(self, config=None):
        """Initialize the framework with optional configuration."""
    
    def process_multimodal_input(self, **kwargs):
        """Process multimodal input and return results."""
    
    def register_domain(self, domain):
        """Register a new domain with the framework."""
```

### BaseMultimodalModel
Foundation model architecture.

```python
class BaseMultimodalModel(nn.Module):
    def forward(self, inputs):
        """Forward pass through the model."""
    
    def encode_modalities(self, inputs):
        """Encode different modalities."""
    
    def fuse_features(self, features):
        """Fuse cross-modal features."""
```

### UniversalTokenizer
Cross-modal tokenization system.

```python
class UniversalTokenizer:
    def encode_multimodal(self, text, modality, domain):
        """Encode multimodal input with domain context."""
    
    def decode_tokens(self, tokens):
        """Decode tokens back to text."""
```

## Domain Classes

### BaseDomain
Base class for domain implementations.

```python
class BaseDomain:
    def process_domain_input(self, inputs):
        """Process domain-specific input."""
    
    def get_domain_config(self):
        """Get domain-specific configuration."""
```

### MedicalDomain
Medical AI domain implementation.

```python
class MedicalDomain(BaseDomain):
    def analyze_medical_image(self, image_path, query, modality):
        """Analyze medical images with clinical context."""
    
    def generate_medical_report(self, findings):
        """Generate structured medical reports."""
```

## Training Classes

### MultiStageTrainer
Multi-stage training pipeline.

```python
class MultiStageTrainer:
    def train_stage1(self):
        """Stage 1: Encoder pretraining."""
    
    def train_stage2(self):
        """Stage 2: Cross-modal alignment."""
    
    def train_stage3(self):
        """Stage 3: Domain fine-tuning."""
    
    def train_stage4(self):
        """Stage 4: Instruction following."""
```

## Utility Functions

### Configuration Management
```python
def load_config(config_path):
    """Load configuration from YAML file."""

def merge_configs(base_config, override_config):
    """Merge configuration dictionaries."""
```

### Data Processing
```python
def preprocess_image(image, target_size):
    """Preprocess image for model input."""

def tokenize_text(text, tokenizer):
    """Tokenize text input."""
```

## Constants and Enums

### ModalityType
```python
class ModalityType(Enum):
    VISION = "vision"
    AUDIO = "audio"
    TEXT = "text"
    SENSOR = "sensor"
```

### DomainType
```python
class DomainType(Enum):
    MEDICAL = "medical"
    AUTONOMOUS = "autonomous"
    ROBOTICS = "robotics"
    EDUCATION = "education"
    GENERAL = "general"
```

## Error Handling

### UMFException
Base exception class for framework errors.

```python
class UMFException(Exception):
    """Base exception for UMF framework."""

class ModelLoadError(UMFException):
    """Error loading model."""

class ConfigurationError(UMFException):
    """Configuration error."""
```
